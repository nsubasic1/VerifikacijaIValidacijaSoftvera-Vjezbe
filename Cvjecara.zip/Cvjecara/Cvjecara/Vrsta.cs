﻿using System;

namespace Cvjecara
{
    public enum Vrsta
    {
        Ruža, Neven, Margareta, Orhideja, Ljiljan
    }
}
